/*
 * L.Projection contains various geographical projections used by CRS classes.
 */

L.Projection = {};
